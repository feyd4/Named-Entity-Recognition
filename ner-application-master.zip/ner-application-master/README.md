# ner-application
Named Entity Recognizer (NER) with Spring Boot

## Video Tutorial

https://www.youtube.com/watch?v=E6gcewlL6jU

https://www.youtube.com/watch?v=yFpxihRf5M8&t=1s

https://www.youtube.com/watch?v=83O0qOMCE6I

## Screen Shot (Extracting Person)

![alt Screenshot_1](https://raw.githubusercontent.com/dineshkrishdev/ner-application/master/src/main/resources/screen-shots/screenshot_1.PNG)
     
## Screen Shot (Extracting Job Title)
     
![alt Screenshot_2](https://raw.githubusercontent.com/dineshkrishdev/ner-application/master/src/main/resources/screen-shots/screenshot_2.PNG)


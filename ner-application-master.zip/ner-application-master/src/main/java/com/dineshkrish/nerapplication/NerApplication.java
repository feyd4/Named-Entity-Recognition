package com.dineshkrish.nerapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NerApplication {

    public static void main(String[] args) {
        SpringApplication.run(NerApplication.class, args);
    }

}

